# 山河志 · 中国三维地形旅游地图

一款 **全屏、可交互、纯前端** 的中国立体地形旅游网站。基于真实 DEM 高程重建中国地势，在可旋转缩放的三维地形上标注全国 **358 处国家 5A 级旅游景区**，点击金色光点即可查看景区简介、实景图集与短视频。

> 技术栈：HTML5 + CSS3 + JavaScript + Three.js（本地内置）  
> 无后端、无数据库、无第三方地图 iframe，所有景区数据静态写在 JS 中。

---

## 预览

| 全屏地图 | 景区详情 |
| --- | --- |
| ![山河志首页](preview/hero.jpg) | ![景区详情](preview/detail.jpg) |

---

## 运行

Three.js 需要浏览器的安全上下文来加载本地纹理，请 **使用静态服务器打开**，不要直接双击 `index.html`（`file://` 会被浏览器 CORS 策略拦截）。

### 方式一：Windows 一键启动

```bat
start.bat
```

脚本会尝试使用系统中的 Python 或 Node.js 启动本地静态服务器，并自动打开浏览器。

### 方式二：手动启动

```bash
# Python 3
python -m http.server 8080

# 或者仅使用 Node.js
node serve.mjs 8080
```

然后访问：<http://127.0.0.1:8080/>

> 如果浏览器提示“纹理加载失败”，99% 是使用了 `file://` 直接打开。请改用上面的静态服务器方式。
> 需要现代浏览器并开启 WebGL（Chrome / Edge / Firefox / Safari 最新版本均可）。

### 快捷键

| 操作 | 效果 |
| --- | --- |
| 鼠标左键拖拽 | 旋转视角 |
| 鼠标滚轮 / `+` `-` | 缩放 |
| 鼠标右键拖拽 | 平移 |
| `/` | 聚焦搜索框 |
| `Esc` | 关闭弹窗 / 搜索 |
| `←` `→` | 在景区详情中切换图片 |

---

## 功能

- **真实地形**：使用 AWS Terrain Tiles（Terrarium 编码，SRTM / ETOPO 等来源）构建中国高程网格；同时进行了 **Web Mercator → 等经纬投影** 的重采样，使山河、水系与经纬度标注严格对齐。
- **分层设色**：按海拔自动生成低地绿、丘陵黄、高原棕黄、高山褐与雪线白的连续色带，并叠加坡向阴影、法线细节与等高线。
- **完整水系**：Natural Earth 10m 河流、湖泊数据按中国陆地轮廓裁切，在 Three.js 着色器中以蓝色半透明流动效果渲染；黄海、东海、南海海面以深海着色器铺在立体版图下方。
- **立体版图**：地形按真实高程夸张隆起（约 13.2 个世界单位），沿海岸与国境生成断崖侧壁和金色边界线，形成可以旋转观看的“悬浮中国”立体模型。
- **358 处 5A 景区**：金色发光立体圆点 + 呼吸光晕 + 地形锚点细线；悬停显示名称、省份、点位海拔，点击打开详情。
- **详情弹窗**：磨砂玻璃质感、缩放淡入动画，包含完整景区文字介绍、3 张图集、景区类型标签、海拔 / 时节 / 建议停留、看点列表，以及可播放/暂停/拖动进度/静音/全屏的自定义视频播放器。
- **检索与随机漫游**：支持按景区名、省份、英文名搜索；支持“随机抵达一处山河”和上一处 / 下一处连续切换。
- **沉浸视觉**：深空星野背景、山体明暗、镜头光晕、自动缓慢旋转、暂停/恢复、标注开关、重置视野、全屏按钮、海拔图例、方位罗盘与坐标式底部状态栏。
- **性能**：纹理压缩（JPG/PNG）、像素比上限、实例化标记、静态阴影贴图冻结、按需加载图集、断网或图片防盗链时自动回退到本地区域风光。

---

## 目录结构

```text
china-scenic-atlas/
├─ index.html                 页面结构与所有 UI
├─ start.bat                  Windows 一键本地预览
├─ serve.mjs                  零依赖 Node 静态服务器
├─ css/
│  └─ style.css               视觉系统与响应式布局
├─ js/
│  └─ app.js                  Three.js 场景、地形、水系、相机交互、弹窗与视频
├─ data/
│  ├─ terrain.js              高程栅格（Uint16 + base64）
│  ├─ landmask.js             中国陆地掩码
│  └─ spots.js                358 处 5A 景区：名称/坐标/简介/图集/视频地址
├─ assets/
│  ├─ terrain-color.jpg       高程分层设色 + 山体阴影
│  ├─ terrain-normal.jpg      地形法线细节
│  ├─ terrain-alpha.png       中国陆地遮罩
│  └─ terrain-water.png       河湖水体遮罩
├─ images/                    可用本地实景图 / 区域风光兜底图
├─ videos/                    按景观主题匹配的短片（Mixkit Free License）
├─ lib/
│  └─ three.min.js            Three.js r160（本地）
└─ preview/                   页面预览图
```

---

## 数据说明

- **5A 名录与坐标**：综合公开的全国 5A 级旅游景区名录及高德/OSM 地理点位整理，共 358 处（补齐世界文化遗产莫高窟）。因景区入口、游客中心与主峰位置不同，页面标注为“点位/位置示意”，以景区官方信息为准。
- **地景高程**：AWS Terrain Tiles（Terrarium）；地形纹理与网格均由真实 DEM 派生。
- **河流与湖泊**：Natural Earth 10m Rivers, Lake Centerlines & Lakes。
- **国界**：DataV GeoAtlas 中国省级边界数据。
- **实景图片**：通过公开图片检索整理的各景区代表性照片，部分景区原图受防盗链限制时，会依次回退到同源缩略图与本地同主题区域风光图。图片版权归原网站/摄影师所有，仅作非商业性的地理科普与视觉展示。
- **视频**：使用 Mixkit Free License 的景观短片，按山岳、湖泊、雪域、古城、城市等类型匹配到景区；如需替换成各景区官方宣传片，只需修改 `data/spots.js` 中每个景区的 `video` 字段（把对应 mp4 放入 `videos/` 即可）。
- **字体**：使用系统中文字体（宋体 / 思源宋体等）与 Inter 回退，不请求外部字体服务。

### 更换景区资料

所有景区数据均在 `data/spots.js`：

```js
window.CHINA_SPOTS = {
  meta: { count: 358, ... },
  list: [
    {
      name: "阿坝州九寨沟景区",
      shortName: "九寨沟",
      province: "四川",
      lat: 33.1445, lon: 103.9107,
      intro: ["第一段简介", "第二段简介"],
      images: [{ url: "images/xxx.jpg", caption: "实景影像" }],
      video: "videos/lake.mp4",
      ...
    }
  ]
};
```

### 性能与兼容

目标平台为桌面端 1440 / 1920 视口；使用 WebGL2，兼容最新版 Chrome、Edge、Firefox、Safari。移动端提供基础响应式布局，但高密度山体与大量 5A 光点更适合大屏。

---

## 图片来源与致谢

- [ChinaTopAttractions · 5A 公开数据](https://chinatopattractions.com/china-attractions-dataset/)
- [GMap · 中国 5A 景区经纬度](https://gmap.net/china-5a-coordinates)
- [AWS Terrain Tiles](https://registry.opendata.aws/terrain-tiles/)
- [Natural Earth](https://www.naturalearthdata.com/)
- [DataV GeoAtlas](https://datav.aliyun.com/portal/school/atlas/area_selector)
- [Three.js](https://threejs.org/)
- [Mixkit Free Stock Video](https://mixkit.co/free-stock-video/) · Mixkit Free License
- 实景图片来自公开发布的网络页面，版权归原作者及原发布网站所有，仅作非商业展示；若需商用请替换为已授权素材。

本作品为地理科普与旅游展示演示，景区开放时间、票价与交通信息请以官方发布为准。
