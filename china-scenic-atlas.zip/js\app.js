/* =========================================================
   山河志 · Atlas of China
   纯前端 Three.js 中国三维地形旅游地图
   ---------------------------------------------------------
   结构：
   1. 基础工具与数据解码
   2. 场景 / 光照 / 背景
   3. 中国地形、水系、海岸断崖与国境线
   4. 5A 景区金色光点与标注
   5. 相机交互、自动旋转与取景
   6. UI：搜索、详情弹窗、图集、短片、说明
   ========================================================= */
(function () {
  'use strict';

  /* =========================================================
     1. 基础工具与数据
     ========================================================= */
  const $ = (id) => document.getElementById(id);
  const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  const META = window.CHINA_TERRAIN;
  const LAND = window.CHINA_LAND_MASK;
  const SPOT_SOURCE = window.CHINA_SPOTS || { meta: {}, list: [] };
  const SPOTS = Array.isArray(SPOT_SOURCE.list) ? SPOT_SOURCE.list : [];
  // 为搜索、随机抵达与前后切换提供稳定的数组索引
  SPOTS.forEach((spot, index) => { spot.__index = index; });

  if (!META) {
    showFatal('地形数据未加载', '请确认 data/terrain.js 文件存在，并通过本地静态服务器打开本页。');
    return;
  }

  const MAP_W = META.mapWidth;
  const MAP_D = META.mapDepth;
  const NX = META.nx;
  const NZ = META.nz;
  const MAX_ELEV = META.maxElev;
  const TERRAIN_H = META.terrainHeight;
  const WORLD_Y = (meters) => (Math.max(0, meters) / MAX_ELEV) * TERRAIN_H;

  // 高程栅格解码（Uint16 little-endian，值 = 高程 + 500）
  const heights = (() => {
    const binary = atob(window.CHINA_HEIGHT_B64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Uint16Array(bytes.buffer);
  })();

  // 陆地掩膜解码（1024 × 760 bit）
  const landMask = (() => {
    const binary = atob(window.CHINA_LAND_B64 || '');
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return { bits: bytes, w: LAND.w, h: LAND.h };
  })();

  function landMaskAt(x, y) {
    if (x < 0 || y < 0 || x >= landMask.w || y >= landMask.h) return 0;
    const idx = y * landMask.w + x;
    return (landMask.bits[idx >> 3] >> (7 - (idx & 7))) & 1;
  }

  function lonLatToXZ(lon, lat) {
    return {
      x: ((lon - META.lonMin) / (META.lonMax - META.lonMin) - 0.5) * MAP_W,
      z: ((META.latMax - lat) / (META.latMax - META.latMin) - 0.5) * MAP_D,
    };
  }

  function xzToLonLat(x, z) {
    return {
      lon: META.lonMin + (x / MAP_W + 0.5) * (META.lonMax - META.lonMin),
      lat: META.latMax - (z / MAP_D + 0.5) * (META.latMax - META.latMin),
    };
  }

  /** 双线性采样高程（米） */
  function sampleElevation(x, z) {
    const gx = clamp((x / MAP_W + 0.5) * (NX - 1), 0, NX - 1);
    const gz = clamp((z / MAP_D + 0.5) * (NZ - 1), 0, NZ - 1);
    const x0 = Math.floor(gx), x1 = Math.min(NX - 1, x0 + 1);
    const z0 = Math.floor(gz), z1 = Math.min(NZ - 1, z0 + 1);
    const tx = gx - x0, tz = gz - z0;
    const a = heights[z0 * NX + x0] - 500;
    const b = heights[z0 * NX + x1] - 500;
    const c = heights[z1 * NX + x0] - 500;
    const d = heights[z1 * NX + x1] - 500;
    return Math.max(0, (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz);
  }

  const surfaceY = (x, z) => WORLD_Y(sampleElevation(x, z));

  function escapeHTML(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (s) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[s]));
  }

  function formatNumber(n) {
    return Math.round(n).toLocaleString('en-US');
  }

  function makePlaceholder(title) {
    const safe = escapeHTML(title || '山河志');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
      <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1b302f"/><stop offset=".55" stop-color="#0c171b"/><stop offset="1" stop-color="#1a2422"/></linearGradient>
      <radialGradient id="r" cx="65%" cy="25%" r="65%"><stop offset="0" stop-color="#99753e" stop-opacity=".35"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient></defs>
      <rect width="1200" height="800" fill="url(#g)"/><rect width="1200" height="800" fill="url(#r)"/>
      <g stroke="#d9c08a" stroke-opacity=".18" fill="none" stroke-width="2">
        <path d="M60 640 260 300l155 218 110-150 255 272 160-214 170 150"/>
        <path d="M60 690 260 350l155 218 110-150 255 272 160-214 170 150" stroke-opacity=".09"/>
        <circle cx="830" cy="252" r="58" stroke-opacity=".14"/>
        <circle cx="830" cy="252" r="82" stroke-opacity=".07"/>
      </g>
      <text x="60" y="112" fill="#d9c08a" fill-opacity=".55" font-family="serif" font-size="23" letter-spacing="9">ATLAS OF CHINA</text>
      <text x="60" y="730" fill="#e9e5d7" fill-opacity=".78" font-family="serif" font-size="38" letter-spacing="5">${safe}</text>
      <text x="62" y="763" fill="#d9c08a" fill-opacity=".35" font-family="sans-serif" font-size="14" letter-spacing="3">SCENIC IMAGE · 资料整理中</text>
    </svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  function showFatal(title, message) {
    const loader = $('loader');
    if (!loader) return;
    loader.innerHTML = `<div class="loader__content"><div class="loader__brand" style="letter-spacing:.2em;text-indent:.2em">${escapeHTML(title)}</div>
      <p class="loader__text" style="margin-top:24px;line-height:1.9;letter-spacing:.06em">${escapeHTML(message || '')}</p>
      <div class="loader__track"><span style="width:34%"></span></div></div>`;
    loader.style.opacity = '1';
    loader.style.visibility = 'visible';
  }

  // DOM references
  const loader = $('loader');
  const loaderBar = $('loaderBar');
  const loaderPct = $('loaderPct');
  const loaderStage = $('loaderStage');
  const canvas = $('scene');
  const markerTip = $('markerTip');
  const tipName = $('tipName');
  const tipMeta = $('tipMeta');

  // 场景核心
  let renderer, scene, camera, clock;
  let mapGroup, labelGroup, seaMesh, starField;
  let terrainMesh, waterMesh, markerMesh, haloPoints, stemLines, borderLines, sideWalls;
  let selectionRing, selectionBeam;
  const markerData = [];
  const labelSprites = [];
  const projected = new THREE.Vector3();
  const temp = new THREE.Vector3();
  const intro = { start: 0, duration: 2200, running: false, done: false };
  let textureSet = null;

  // 相机状态
  const defaultOverviewRadius = () => clamp(212 / Math.max(1.1, window.innerWidth / window.innerHeight), 136, 166);
  const cameraRig = {
    theta: -0.13,
    phi: 0.72,
    radius: defaultOverviewRadius() + 42,
    targetTheta: -0.13,
    targetPhi: 0.72,
    targetRadius: defaultOverviewRadius(),
    center: new THREE.Vector3(-2.4, 2.2, 0),
    targetCenter: new THREE.Vector3(-2.4, 2.2, 0),
    minRadius: 51,
    maxRadius: 250,
    minPhi: 0.21,
    maxPhi: 1.31,
  };

  const appState = {
    ready: false,
    introDone: false,
    autoRotate: !prefersReduced,
    labelsVisible: true,
    lastInteraction: performance.now() + 2400,
    dragging: false,
    dragButton: -1,
    dragStartX: 0,
    dragStartY: 0,
    dragLastX: 0,
    dragLastY: 0,
    dragDistance: 0,
    pointerX: innerWidth / 2,
    pointerY: innerHeight / 2,
    pointerInside: false,
    hovered: -1,
    selected: -1,
    spotOpen: false,
    infoOpen: false,
    activeSpot: -1,
    galleryIndex: 0,
    galleryToken: 0,
    searchActive: -1,
    searchResults: [],
    lastFocus: null,
    lastHoverCheck: 0,
  };

  const loading = {
    value: 0,
    set(value, text) {
      this.value = Math.max(this.value, clamp(value, 0, 100));
      if (loaderBar) loaderBar.style.width = this.value + '%';
      if (loaderPct) loaderPct.textContent = String(Math.floor(this.value)).padStart(2, '0');
      if (text && loaderStage) loaderStage.textContent = text;
    },
  };

  /* =========================================================
     2. 场景 / 光照 / 背景
     ========================================================= */
  function initScene() {
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch (err) {
      showFatal('无法启动 3D 地形', '当前浏览器没有可用的 WebGL 环境，请开启硬件加速或使用最新版 Chrome / Edge。');
      throw err;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.14;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x071118, 0.00105);
    buildSkyBackground();

    camera = new THREE.PerspectiveCamera(38, window.innerWidth / window.innerHeight, 0.2, 1000);
    camera.position.set(0, 120, 160);

    clock = new THREE.Clock();

    // 光照：柔和天光 + 西北向暖阳 + 冷色补光
    const hemi = new THREE.HemisphereLight(0x9bbbc9, 0x16100b, 0.78);
    scene.add(hemi);

    const ambient = new THREE.AmbientLight(0x203e44, 0.32);
    scene.add(ambient);

    const sun = new THREE.DirectionalLight(0xffe0b0, 3.1);
    sun.position.set(-105, 146, 88);
    sun.target.position.set(0, 0, 0);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -104;
    sun.shadow.camera.right = 104;
    sun.shadow.camera.top = 96;
    sun.shadow.camera.bottom = -96;
    sun.shadow.camera.near = 12;
    sun.shadow.camera.far = 380;
    sun.shadow.bias = -0.00028;
    sun.shadow.normalBias = 0.12;
    scene.add(sun);
    scene.add(sun.target);

    const fill = new THREE.DirectionalLight(0x74b6ce, 0.65);
    fill.position.set(105, 68, -84);
    scene.add(fill);

    const rim = new THREE.DirectionalLight(0xd9b779, 0.34);
    rim.position.set(34, 35, -120);
    scene.add(rim);

    mapGroup = new THREE.Group();
    mapGroup.name = 'china-map-group';
    scene.add(mapGroup);

    labelGroup = new THREE.Group();
    labelGroup.name = 'map-labels';
    scene.add(labelGroup);

    buildStars();
    buildSea();
    buildSelectionFx();

    window.addEventListener('resize', onResize);
    if (renderer.shadowMap) renderer.shadowMap.autoUpdate = true;
  }

  /** 生成深空背景：星野、银河微光与深蓝渐变，作为场景背景铺满整屏 */
  function buildSkyBackground() {
    const c = document.createElement('canvas');
    c.width = 2048;
    c.height = 1152;
    const ctx = c.getContext('2d');
    const w = c.width, h = c.height;

    const bg = ctx.createLinearGradient(0, 0, w * .7, h);
    bg.addColorStop(0, '#06131a');
    bg.addColorStop(.32, '#040d12');
    bg.addColorStop(.62, '#02080c');
    bg.addColorStop(1, '#050c11');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    // 远处的青绿色星云与暖金色尘埃
    const nebulas = [
      [.68, .34, .48, 'rgba(43, 104, 106, 0.2)'],
      [.30, .78, .42, 'rgba(125, 88, 44, 0.12)'],
      [.52, .48, .62, 'rgba(31, 71, 79, 0.15)'],
      [.9, .12, .28, 'rgba(101, 76, 44, 0.1)'],
    ];
    nebulas.forEach(([x, y, r, color]) => {
      const rg = ctx.createRadialGradient(x * w, y * h, 0, x * w, y * h, r * w);
      rg.addColorStop(0, color);
      rg.addColorStop(.48, color.replace(/[\d.]+\)$/, '0.035)'));
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, w, h);
    });

    // 一条极淡的银河带
    ctx.save();
    ctx.translate(w * .46, h * .42);
    ctx.rotate(-0.42);
    const band = ctx.createLinearGradient(0, -h * .17, 0, h * .17);
    band.addColorStop(0, 'rgba(120, 161, 164, 0)');
    band.addColorStop(.42, 'rgba(125, 159, 157, 0.035)');
    band.addColorStop(.56, 'rgba(182, 189, 171, 0.05)');
    band.addColorStop(1, 'rgba(120, 161, 164, 0)');
    ctx.fillStyle = band;
    ctx.fillRect(-w * .55, -h * .18, w * 1.1, h * .36);
    ctx.restore();

    let seed = 20261116;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    };

    // 大量细小星点
    for (let i = 0; i < 1850; i++) {
      const x = rand() * w;
      const y = rand() * h;
      const big = Math.pow(rand(), 8);
      const radius = .55 + big * 2.0;
      const alpha = .22 + rand() * .5 + big * .22;
      const warm = rand() > .78;
      ctx.beginPath();
      ctx.fillStyle = warm ? `rgba(237, 214, 170, ${alpha})` : `rgba(193, 220, 225, ${alpha})`;
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
      if (big > .32) {
        const g = ctx.createRadialGradient(x, y, 0, x, y, radius * 8);
        g.addColorStop(0, warm ? 'rgba(236, 208, 158, .2)' : 'rgba(177, 216, 226, .18)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, radius * 8, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 少量更亮的星，带一点十字光芒
    for (let i = 0; i < 24; i++) {
      const x = rand() * w;
      const y = rand() * h * .86 + h * .04;
      const r = 1.0 + rand() * 1.5;
      ctx.save();
      ctx.translate(x, y);
      ctx.strokeStyle = `rgba(220, 226, 207, ${.12 + rand() * .14})`;
      ctx.lineWidth = .55;
      ctx.beginPath();
      ctx.moveTo(-r * 5, 0); ctx.lineTo(r * 5, 0);
      ctx.moveTo(0, -r * 4); ctx.lineTo(0, r * 4);
      ctx.stroke();
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r * 7);
      g.addColorStop(0, 'rgba(247, 241, 217, .8)');
      g.addColorStop(.2, 'rgba(209, 224, 218, .28)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, r * 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 四周轻微压暗，中心偏下留一点深青色的呼吸
    const glow = ctx.createRadialGradient(w * .56, h * .5, 0, w * .56, h * .5, w * .55);
    glow.addColorStop(0, 'rgba(23, 69, 72, 0.07)');
    glow.addColorStop(.65, 'rgba(8, 27, 33, 0.02)');
    glow.addColorStop(1, 'rgba(0, 3, 5, 0.25)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, h);

    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    scene.background = tex;
  }

  function buildStars() {
    const count = 2400;
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const phases = new Float32Array(count);
    const colors = new Float32Array(count * 3);
    const palette = [
      [0.71, 0.84, 0.9],
      [0.91, 0.85, 0.69],
      [0.55, 0.76, 0.8],
      [0.93, 0.93, 0.9],
    ];

    for (let i = 0; i < count; i++) {
      // 球壳：避开镜头内部
      const r = 215 + Math.random() * 330;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(THREE.MathUtils.randFloatSpread(2) * 0.82 + 0.09);
      positions[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
      positions[i * 3 + 1] = Math.abs(Math.cos(phi)) * r * 0.62 - 15;
      positions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
      sizes[i] = 0.8 + Math.pow(Math.random(), 3) * 2.7;
      phases[i] = Math.random() * Math.PI * 2;
      const c = palette[(Math.random() * palette.length) | 0];
      colors[i * 3] = c[0];
      colors[i * 3 + 1] = c[1];
      colors[i * 3 + 2] = c[2];
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      depthTest: true,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
      },
      vertexShader: `
        attribute float aSize;
        attribute float aPhase;
        attribute vec3 aColor;
        varying float vAlpha;
        varying vec3 vColor;
        uniform float uTime;
        uniform float uPixelRatio;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          float twinkle = 0.62 + 0.38 * sin(uTime * 0.42 + aPhase);
          gl_PointSize = clamp(aSize * uPixelRatio * (560.0 / max(1.0, -mv.z)), 0.75, 4.0);
          vAlpha = twinkle * clamp(500.0 / -mv.z, 0.27, 1.0);
          vColor = aColor;
        }
      `,
      fragmentShader: `
        varying float vAlpha;
        varying vec3 vColor;
        void main() {
          vec2 p = gl_PointCoord - 0.5;
          float d = length(p);
          float core = smoothstep(0.24, 0.0, d);
          float halo = smoothstep(0.5, 0.1, d) * 0.38;
          float a = (core + halo) * vAlpha;
          if (a < 0.01) discard;
          gl_FragColor = vec4(vColor, a);
        }
      `,
    });
    starField = new THREE.Points(geometry, material);
    starField.renderOrder = -10;
    labelGroup.add(starField);
    // 星星放到 labelGroup 之外，避免标注开关影响
    labelGroup.remove(starField);
    scene.add(starField);
  }

  function buildSea() {
    const geometry = new THREE.PlaneGeometry(760, 620, 1, 1);
    const material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      uniforms: {
        uTime: { value: 0 },
        uColorA: { value: new THREE.Color(0x0b2530) },
        uColorB: { value: new THREE.Color(0x15505a) },
      },
      vertexShader: `
        varying vec3 vWorld;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uColorA;
        uniform vec3 uColorB;
        varying vec3 vWorld;
        float hash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noise(vec2 p) {
          vec2 i = floor(p); vec2 f = fract(p);
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                     mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
        }
        void main() {
          float d = length(vWorld.xz);
          vec2 p = vWorld.xz * 0.045;
          float n = noise(p + vec2(uTime * 0.018, -uTime * 0.012)) * 0.6
                  + noise(p * 2.7 + vec2(-uTime * 0.03, uTime * 0.02)) * 0.4;
          float wave = sin(vWorld.x * 0.08 + uTime * 0.06) * sin(vWorld.z * 0.055 - uTime * 0.045);
          float halo = exp(-pow(d / 92.0, 2.0)) * 0.5;
          float shore = exp(-pow((d - 106.0) / 42.0, 2.0));
          vec3 col = mix(uColorA, uColorB, n * 0.28 + wave * 0.07 + halo * 0.62);
          col += vec3(0.022, 0.075, 0.074) * pow(max(wave, 0.0), 3.0);
          col += vec3(0.08, 0.19, 0.17) * shore * 0.1;
          col += vec3(0.045, 0.085, 0.07) * exp(-pow(d / 46.0, 2.0)) * 0.28;
          float fade = 1.0 - smoothstep(230.0, 370.0, d);
          gl_FragColor = vec4(col, fade * 0.96);
        }
      `,
    });
    seaMesh = new THREE.Mesh(geometry, material);
    seaMesh.rotation.x = -Math.PI / 2;
    seaMesh.position.y = -0.72;
    seaMesh.renderOrder = -5;
    scene.add(seaMesh);

    // 岛下柔光
    const glowTex = makeRadialTexture(256, [
      [0, 'rgba(113,190,190,0.35)'],
      [0.35, 'rgba(62,126,127,0.13)'],
      [0.7, 'rgba(25,62,64,0.045)'],
      [1, 'rgba(0,0,0,0)'],
    ]);
    const glowMat = new THREE.MeshBasicMaterial({
      map: glowTex,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0.62,
      toneMapped: false,
    });
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(210, 164), glowMat);
    glow.rotation.x = -Math.PI / 2;
    glow.position.y = -0.45;
    glow.renderOrder = -4;
    scene.add(glow);
  }

  function makeRadialTexture(size, stops) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    stops.forEach(([offset, color]) => g.addColorStop(offset, color));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  /* =========================================================
     3. 中国地形、水系、海岸断崖与国境线
     ========================================================= */
  function loadTexture(url, colorSpace) {
    return new Promise((resolve, reject) => {
      new THREE.TextureLoader()
        .setCrossOrigin('anonymous')
        .load(
          url,
          (texture) => {
            texture.flipY = false;
            texture.colorSpace = colorSpace || THREE.NoColorSpace;
            texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
            texture.minFilter = THREE.LinearMipmapLinearFilter;
            texture.magFilter = THREE.LinearFilter;
            texture.needsUpdate = true;
            resolve(texture);
          },
          undefined,
          reject
        );
    });
  }

  async function loadTerrainAssets() {
    loading.set(19, '铺展真实地表纹理');
    const map = await loadTexture('assets/terrain-color.jpg', THREE.SRGBColorSpace);
    loading.set(32, '校准山体光影');
    const normal = await loadTexture('assets/terrain-normal.jpg');
    loading.set(45, '描摹江河湖海');
    const water = await loadTexture('assets/terrain-water.png');
    loading.set(54, '裁出中国轮廓');
    const alpha = await loadTexture('assets/terrain-alpha.png');
    textureSet = { map, normal, water, alpha };
  }

  function buildTerrain() {
    const nx = NX, nz = NZ;
    const vertexCount = nx * nz;
    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    for (let iz = 0; iz < nz; iz++) {
      const z = -MAP_D / 2 + (iz / (nz - 1)) * MAP_D;
      const v = iz / (nz - 1);
      for (let ix = 0; ix < nx; ix++) {
        const x = -MAP_W / 2 + (ix / (nx - 1)) * MAP_W;
        const i = iz * nx + ix;
        positions[i * 3] = x;
        positions[i * 3 + 1] = WORLD_Y(heights[i] - 500);
        positions[i * 3 + 2] = z;
        uvs[i * 2] = ix / (nx - 1);
        uvs[i * 2 + 1] = v;
      }
    }

    const quadCount = (nx - 1) * (nz - 1);
    const indices = new Uint32Array(quadCount * 6);
    let k = 0;
    for (let iz = 0; iz < nz - 1; iz++) {
      for (let ix = 0; ix < nx - 1; ix++) {
        const a = iz * nx + ix;
        const b = a + 1;
        const c = a + nx;
        const d = c + 1;
        // 逆时针向上
        indices[k++] = a; indices[k++] = c; indices[k++] = d;
        indices[k++] = a; indices[k++] = d; indices[k++] = b;
      }
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
    geometry.setIndex(new THREE.BufferAttribute(indices, 1));
    geometry.computeVertexNormals();
    geometry.computeBoundingSphere();

    const material = new THREE.MeshStandardMaterial({
      map: textureSet.map,
      normalMap: textureSet.normal,
      normalScale: new THREE.Vector2(0.62, 0.62),
      roughness: 0.9,
      metalness: 0.015,
      alphaMap: textureSet.alpha,
      alphaTest: 0.32,
      transparent: false,
      side: THREE.FrontSide,
    });
    material.shadowSide = THREE.FrontSide;

    terrainMesh = new THREE.Mesh(geometry, material);
    terrainMesh.castShadow = true;
    terrainMesh.receiveShadow = true;
    terrainMesh.renderOrder = 1;

    // 阴影用透明度裁剪，避免地形阴影变成矩形
    const depthMaterial = new THREE.MeshDepthMaterial({
      depthPacking: THREE.RGBADepthPacking,
      alphaMap: textureSet.alpha,
      alphaTest: 0.4,
    });
    terrainMesh.customDepthMaterial = depthMaterial;
    mapGroup.add(terrainMesh);

    buildWaterOverlay(geometry);
    buildIsland(geometry);
  }

  function buildWaterOverlay(geometry) {
    const material = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      depthTest: true,
      side: THREE.FrontSide,
      polygonOffset: true,
      polygonOffsetFactor: -3,
      polygonOffsetUnits: -3,
      uniforms: {
        uWater: { value: textureSet.water },
        uTime: { value: 0 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D uWater;
        uniform float uTime;
        varying vec2 vUv;
        void main() {
          float m = texture2D(uWater, vUv).r;
          if (m < 0.035) discard;
          vec2 p = vUv * vec2(2200.0, 1650.0);
          float ripple = sin(p.y * 0.055 + uTime * 0.9 + sin(p.x * 0.041 + uTime * 0.22)) * 0.5 + 0.5;
          float ripple2 = sin((p.x + p.y) * 0.023 - uTime * 0.48) * 0.5 + 0.5;
          float glint = smoothstep(0.80, 1.0, ripple * 0.7 + ripple2 * 0.3);
          vec3 deep = vec3(0.028, 0.135, 0.175);
          vec3 light = vec3(0.105, 0.43, 0.49);
          vec3 col = mix(deep, light, 0.42 + ripple * 0.34);
          col += vec3(0.48, 0.70, 0.64) * glint * 0.22;
          float alpha = clamp(m * (0.55 + ripple * 0.2), 0.0, 0.87);
          gl_FragColor = vec4(col, alpha);
        }
      `,
    });
    waterMesh = new THREE.Mesh(geometry, material);
    waterMesh.renderOrder = 3;
    waterMesh.frustumCulled = true;
    mapGroup.add(waterMesh);
  }

  function buildIsland(terrainGeometry) {
    const w = landMask.w;
    const h = landMask.h;
    const positions = [];
    const colors = [];
    const indices = [];
    const borderPositions = [];
    const xAt = (px) => -MAP_W / 2 + (px / w) * MAP_W;
    const zAt = (py) => -MAP_D / 2 + (py / h) * MAP_D;

    const topColor = new THREE.Color(0x3a3023);
    const topColorWarm = new THREE.Color(0x4a3d2a);
    const bottomColor = new THREE.Color(0x040a0c);
    const color = new THREE.Color();
    const baseY = -3.35;

    // 每个陆地像素的四条边：生成垂直断崖和顶缘金线
    for (let py = 0; py < h; py++) {
      for (let px = 0; px < w; px++) {
        if (!landMaskAt(px, py)) continue;
        const cx = xAt(px + 0.5);
        const cz = zAt(py + 0.5);
        const ground = surfaceY(cx, cz);
        const edgeHeight = Math.max(0.02, ground);

        const edges = [
          { inside: landMaskAt(px - 1, py), x1: px, z1: py, x2: px, z2: py + 1 },
          { inside: landMaskAt(px + 1, py), x1: px + 1, z1: py, x2: px + 1, z2: py + 1 },
          { inside: landMaskAt(px, py - 1), x1: px, z1: py, x2: px + 1, z2: py },
          { inside: landMaskAt(px, py + 1), x1: px, z1: py + 1, x2: px + 1, z2: py + 1 },
        ];

        for (const e of edges) {
          if (e.inside) continue;
          const ax = xAt(e.x1), az = zAt(e.z1);
          const bx = xAt(e.x2), bz = zAt(e.z2);
          // 顶部两点、底部两点
          const base = positions.length / 3;
          positions.push(ax, edgeHeight, az, bx, edgeHeight, bz, bx, baseY, bz, ax, baseY, az);

          color.copy(topColor).lerp(topColorWarm, 0.35 + 0.3 * Math.sin(px * 0.07 + py * 0.04));
          colors.push(color.r, color.g, color.b);
          color.copy(topColor).lerp(topColorWarm, 0.14);
          colors.push(color.r, color.g, color.b);
          colors.push(bottomColor.r, bottomColor.g, bottomColor.b);
          colors.push(bottomColor.r, bottomColor.g, bottomColor.b);

          indices.push(base, base + 1, base + 2, base, base + 2, base + 3);

          // 顶部描边
          borderPositions.push(ax, edgeHeight + 0.035, az, bx, edgeHeight + 0.035, bz);
        }
      }
    }

    if (positions.length) {
      const wallGeo = new THREE.BufferGeometry();
      wallGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      wallGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      wallGeo.setIndex(indices);
      wallGeo.computeVertexNormals();

      // 断崖不参与光照，避免夸张地形边缘出现亮暗相间的“栅栏”条纹
      const wallMat = new THREE.MeshBasicMaterial({
        vertexColors: true,
        side: THREE.DoubleSide,
        toneMapped: true,
      });
      sideWalls = new THREE.Mesh(wallGeo, wallMat);
      sideWalls.castShadow = false;
      sideWalls.receiveShadow = false;
      sideWalls.renderOrder = 0;
      mapGroup.add(sideWalls);
    }

    if (borderPositions.length) {
      const borderGeo = new THREE.BufferGeometry();
      borderGeo.setAttribute('position', new THREE.Float32BufferAttribute(borderPositions, 3));
      const borderMat = new THREE.LineBasicMaterial({
        color: 0xf0d18c,
        transparent: true,
        opacity: 0.54,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      borderLines = new THREE.LineSegments(borderGeo, borderMat);
      borderLines.renderOrder = 4;
      mapGroup.add(borderLines);
    }
  }

  /* =========================================================
     4. 5A 景区光点 / 标注 / 选中特效
     ========================================================= */
  function spotWorldPosition(spot, index) {
    const { x, z } = lonLatToXZ(spot.lon, spot.lat);
    const y = surfaceY(x, z);
    return { x, y, z, markerY: y + (spot.featured ? 1.25 : 1.1) };
  }

  function buildMarkers() {
    if (!SPOTS.length) return;
    const coreGeo = new THREE.IcosahedronGeometry(0.345, 1);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0xffdc92,
      emissive: 0xc58b2f,
      emissiveIntensity: 0.86,
      metalness: 0.62,
      roughness: 0.27,
      flatShading: true,
      toneMapped: true,
    });

    markerMesh = new THREE.InstancedMesh(coreGeo, coreMat, SPOTS.length);
    markerMesh.castShadow = false;
    markerMesh.receiveShadow = false;
    markerMesh.frustumCulled = false;
    markerMesh.renderOrder = 11;
    markerMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mapGroup.add(markerMesh);

    const dummy = new THREE.Object3D();
    const baseColor = new THREE.Color(0xffd383);
    const gold = new THREE.Color(0xffcf6f);

    const haloPositions = new Float32Array(SPOTS.length * 3);
    const haloPhases = new Float32Array(SPOTS.length);
    const haloIndices = new Float32Array(SPOTS.length);
    const stemPositions = new Float32Array(SPOTS.length * 6);

    SPOTS.forEach((spot, i) => {
      const p = spotWorldPosition(spot, i);
      markerData.push(p);

      dummy.position.set(p.x, p.markerY, p.z);
      dummy.scale.setScalar(1);
      dummy.rotation.set(0.2 + i * 0.8, i * 1.7, 0.1);
      dummy.updateMatrix();
      markerMesh.setMatrixAt(i, dummy.matrix);
      markerMesh.setColorAt(i, gold.clone().lerp(baseColor, (i % 5) * 0.06));

      haloPositions[i * 3] = p.x;
      haloPositions[i * 3 + 1] = p.markerY;
      haloPositions[i * 3 + 2] = p.z;
      haloPhases[i] = (i * 2.399) % (Math.PI * 2);
      haloIndices[i] = i;

      stemPositions[i * 6] = p.x;
      stemPositions[i * 6 + 1] = p.y + 0.07;
      stemPositions[i * 6 + 2] = p.z;
      stemPositions[i * 6 + 3] = p.x;
      stemPositions[i * 6 + 4] = p.markerY - 0.17;
      stemPositions[i * 6 + 5] = p.z;
    });
    markerMesh.instanceMatrix.needsUpdate = true;
    if (markerMesh.instanceColor) markerMesh.instanceColor.needsUpdate = true;

    const haloGeo = new THREE.BufferGeometry();
    haloGeo.setAttribute('position', new THREE.BufferAttribute(haloPositions, 3));
    haloGeo.setAttribute('aPhase', new THREE.BufferAttribute(haloPhases, 1));
    haloGeo.setAttribute('aIndex', new THREE.BufferAttribute(haloIndices, 1));

    const haloMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      depthTest: true,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
        uHover: { value: -1 },
        uSelected: { value: -1 },
      },
      vertexShader: `
        attribute float aPhase;
        attribute float aIndex;
        varying float vAlpha;
        varying float vGlow;
        uniform float uTime;
        uniform float uPixelRatio;
        uniform float uHover;
        uniform float uSelected;
        void main() {
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          float hover = max(1.0 - abs(aIndex - uHover), 0.0);
          float selected = max(1.0 - abs(aIndex - uSelected), 0.0);
          float breath = 0.5 + 0.5 * sin(uTime * 1.34 + aPhase);
          float size = (4.2 + breath * 1.9 + hover * 6.2 + selected * 7.4) * uPixelRatio * (280.0 / max(1.0, -mv.z));
          gl_PointSize = clamp(size, 1.4, 26.0);
          vAlpha = (0.5 + breath * 0.2 + hover * 0.24 + selected * 0.20) * clamp(250.0 / -mv.z, 0.3, 1.4);
          vGlow = breath + hover * 0.8 + selected * 0.9;
        }
      `,
      fragmentShader: `
        varying float vAlpha;
        varying float vGlow;
        void main() {
          vec2 p = gl_PointCoord - 0.5;
          float d = length(p);
          float aura = smoothstep(0.5, 0.03, d);
          float core = smoothstep(0.22, 0.0, d);
          float alpha = aura * aura * 0.52 + core * 0.45;
          vec3 warm = mix(vec3(1.0, 0.66, 0.23), vec3(1.0, 0.92, 0.67), core);
          gl_FragColor = vec4(warm + vGlow * 0.05, alpha * vAlpha);
        }
      `,
    });
    haloPoints = new THREE.Points(haloGeo, haloMat);
    haloPoints.renderOrder = 12;
    haloPoints.frustumCulled = false;
    mapGroup.add(haloPoints);

    const stemGeo = new THREE.BufferGeometry();
    stemGeo.setAttribute('position', new THREE.BufferAttribute(stemPositions, 3));
    const stemMat = new THREE.LineBasicMaterial({
      color: 0xe5c276,
      transparent: true,
      opacity: 0.19,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    stemLines = new THREE.LineSegments(stemGeo, stemMat);
    stemLines.renderOrder = 10;
    mapGroup.add(stemLines);
  }

  function buildSelectionFx() {
    const ringGeo = new THREE.RingGeometry(1.05, 1.17, 72);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf2d696,
      transparent: true,
      opacity: 0.78,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    });
    selectionRing = new THREE.Mesh(ringGeo, ringMat);
    selectionRing.rotation.x = -Math.PI / 2;
    selectionRing.visible = false;
    selectionRing.renderOrder = 9;
    mapGroup.add(selectionRing);

    // 细长的金色光柱，只在选中时出现
    const c = document.createElement('canvas');
    c.width = 96;
    c.height = 512;
    const ctx = c.getContext('2d');
    const g = ctx.createLinearGradient(0, 512, 0, 0);
    g.addColorStop(0, 'rgba(255,226,159,0.5)');
    g.addColorStop(0.18, 'rgba(248,208,124,0.26)');
    g.addColorStop(0.62, 'rgba(237,183,90,0.075)');
    g.addColorStop(1, 'rgba(237,183,90,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 96, 512);
    const beamTex = new THREE.CanvasTexture(c);
    beamTex.colorSpace = THREE.SRGBColorSpace;
    const beamMat = new THREE.SpriteMaterial({
      map: beamTex,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0.92,
      toneMapped: false,
    });
    selectionBeam = new THREE.Sprite(beamMat);
    selectionBeam.center.set(0.5, 0);
    selectionBeam.scale.set(2.1, 15, 1);
    selectionBeam.visible = false;
    selectionBeam.renderOrder = 9;
    mapGroup.add(selectionBeam);
  }

  function updateMarkerAppearance(i) {
    if (!markerMesh || i < 0 || i >= SPOTS.length) return;
    const dummy = new THREE.Object3D();
    const p = markerData[i];
    const active = i === appState.hovered || i === appState.selected;
    const scale = active ? (i === appState.selected ? 1.55 : 1.38) : 1;
    dummy.position.set(p.x, p.markerY, p.z);
    dummy.scale.setScalar(scale);
    dummy.rotation.set(0.2 + i * 0.8, i * 1.7, 0.1);
    dummy.updateMatrix();
    markerMesh.setMatrixAt(i, dummy.matrix);
    markerMesh.instanceMatrix.needsUpdate = true;
    if (markerMesh.instanceColor) {
      const c = new THREE.Color(active ? 0xfff0ba : 0xffcf6f);
      markerMesh.setColorAt(i, c);
      markerMesh.instanceColor.needsUpdate = true;
    }
    if (haloPoints) {
      haloPoints.material.uniforms.uHover.value = appState.hovered;
      haloPoints.material.uniforms.uSelected.value = appState.selected;
    }
  }

  function setSelectedFx(i, visible) {
    if (!selectionRing || !selectionBeam) return;
    if (!visible || i < 0 || !markerData[i]) {
      selectionRing.visible = false;
      selectionBeam.visible = false;
      return;
    }
    const p = markerData[i];
    selectionRing.position.set(p.x, p.y + 0.095, p.z);
    selectionRing.visible = true;
    selectionBeam.position.set(p.x, p.y + 0.02, p.z);
    selectionBeam.visible = true;
  }

  /* =========================================================
     地理标注
     ========================================================= */
  const PROVINCES = [
    ['北京', 116.4, 40.22], ['天津', 117.32, 39.3], ['河北', 115.42, 38.3],
    ['山西', 112.3, 37.62], ['内蒙古', 112.4, 44.1], ['辽宁', 122.9, 41.55],
    ['吉林', 126.2, 43.7], ['黑龙江', 127.7, 48.1], ['上海', 121.5, 31.15],
    ['江苏', 119.5, 33.05], ['浙江', 120.1, 29.2], ['安徽', 117.18, 31.82],
    ['福建', 118.0, 26.1], ['江西', 115.72, 27.62], ['山东', 118.17, 36.4],
    ['河南', 113.62, 33.9], ['湖北', 112.27, 31.0], ['湖南', 111.7, 27.62],
    ['广东', 113.42, 23.35], ['广西', 108.79, 23.82], ['海南', 109.75, 19.16],
    ['重庆', 107.85, 30.02], ['四川', 102.7, 30.65], ['贵州', 106.88, 26.82],
    ['云南', 101.48, 25.0], ['西藏', 88.4, 31.55], ['陕西', 108.93, 35.3],
    ['甘肃', 103.82, 36.1], ['青海', 96.05, 35.72], ['宁夏', 106.17, 37.3],
    ['新疆', 85.3, 41.4], ['台湾', 120.98, 23.7], ['香港', 114.17, 22.32],
    ['澳门', 113.55, 22.17],
  ];

  const LANDFORMS = [
    ['青藏高原', 'QINGHAI–TIBET PLATEAU', 88.1, 32.7, 0.58],
    ['塔里木盆地', 'TARIM BASIN', 83.2, 39.7, 0.48],
    ['准噶尔盆地', 'JUNGGAR BASIN', 86.1, 45.4, 0.42],
    ['柴达木盆地', 'QAIDAM BASIN', 94.2, 37.2, 0.42],
    ['四川盆地', 'SICHUAN BASIN', 105.35, 30.4, 0.46],
    ['黄土高原', 'LOESS PLATEAU', 108.9, 36.2, 0.41],
    ['内蒙古高原', 'INNER MONGOLIAN PLATEAU', 112.3, 43.55, 0.37],
    ['云贵高原', 'YUNNAN–GUIZHOU PLATEAU', 104.5, 25.3, 0.4],
    ['东北平原', 'NORTHEAST CHINA PLAIN', 124.3, 46.7, 0.36],
    ['华北平原', 'NORTH CHINA PLAIN', 116.2, 35.1, 0.34],
    ['喜马拉雅山脉', 'HIMALAYAS', 85.7, 28.2, 0.38],
    ['昆仑山脉', 'KUNLUN MOUNTAINS', 84.4, 35.9, 0.35],
    ['天山山脉', 'TIAN SHAN', 84.4, 42.85, 0.38],
    ['祁连山脉', 'QILIAN MOUNTAINS', 98.7, 38.7, 0.3],
    ['秦岭', 'QINLING', 107.3, 33.85, 0.36],
    ['大兴安岭', 'GREATER KHINGAN', 122.3, 49.35, 0.3],
    ['横断山脉', 'HENGDUAN MOUNTAINS', 98.9, 27.45, 0.32],
  ];

  function makeLabel(text, sub, type) {
    const isLandform = type === 'landform';
    const mainFont = isLandform
      ? '500 42px "Songti SC", "STSong", "SimSun", "Noto Serif SC", serif'
      : '500 29px "Microsoft YaHei", "PingFang SC", sans-serif';
    const subFont = '400 11px "Inter", "Microsoft YaHei", sans-serif';
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d');
    ctx.font = mainFont;
    if ('letterSpacing' in ctx) ctx.letterSpacing = isLandform ? '5px' : '4px';
    const mainW = ctx.measureText(text).width;
    ctx.font = subFont;
    if ('letterSpacing' in ctx) ctx.letterSpacing = '3px';
    const subW = sub ? ctx.measureText(sub).width : 0;
    const scale = 2;
    const contentW = Math.max(mainW, subW);
    c.width = Math.ceil(contentW + 64) * scale;
    c.height = (isLandform ? 114 : 64) * scale;
    ctx.scale(scale, scale);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.82)';
    ctx.shadowBlur = 10;
    ctx.font = mainFont;
    if ('letterSpacing' in ctx) ctx.letterSpacing = isLandform ? '5px' : '4px';
    ctx.fillStyle = isLandform ? 'rgba(243,236,216,0.98)' : 'rgba(235,243,237,0.9)';
    ctx.fillText(text, c.width / scale / 2, isLandform ? 39 : 27);
    if (sub) {
      ctx.font = subFont;
      if ('letterSpacing' in ctx) ctx.letterSpacing = '3px';
      ctx.fillStyle = isLandform ? 'rgba(220,191,135,0.72)' : 'rgba(198,212,204,0.52)';
      ctx.fillText(sub, c.width / scale / 2, isLandform ? 78 : 49);
    }
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;
    const mat = new THREE.SpriteMaterial({
      map: tex,
      transparent: true,
      depthWrite: false,
      depthTest: false,
      opacity: isLandform ? 0.95 : 0.72,
      toneMapped: false,
    });
    const sprite = new THREE.Sprite(mat);
    const worldHeight = isLandform ? 4.15 : 2.35;
    sprite.scale.set((c.width / c.height) * worldHeight, worldHeight, 1);
    return sprite;
  }

  function buildLabels() {
    const add = (text, sub, lon, lat, type, baseOpacity) => {
      const { x, z } = lonLatToXZ(lon, lat);
      const y = surfaceY(x, z);
      const sprite = makeLabel(text, sub, type);
      sprite.position.set(x, y + (type === 'landform' ? 2.4 : 1.45), z);
      sprite.material.opacity = baseOpacity;
      sprite.userData.baseOpacity = baseOpacity;
      sprite.userData.type = type;
      labelSprites.push(sprite);
      labelGroup.add(sprite);
    };
    PROVINCES.forEach(([name, lon, lat]) => add(name, '', lon, lat, 'province', 0.56));
    LANDFORMS.forEach(([name, sub, lon, lat, op]) => add(name, sub, lon, lat, 'landform', Math.min(0.9, op * 1.35 + 0.24)));
  }

  /* =========================================================
     5. 相机交互
     ========================================================= */
  function updateCamera(dt, instant) {
    if (!camera) return;
    const now = performance.now();
    const idle = now - appState.lastInteraction > 2800;
    if (appState.autoRotate && appState.ready && appState.introDone && !appState.dragging && !appState.spotOpen && !appState.infoOpen && appState.hovered < 0 && idle) {
      cameraRig.targetTheta += dt * 0.025;
    }

    if (instant) {
      cameraRig.theta = cameraRig.targetTheta;
      cameraRig.phi = cameraRig.targetPhi;
      cameraRig.radius = cameraRig.targetRadius;
      cameraRig.center.copy(cameraRig.targetCenter);
    } else {
      const smooth = 1 - Math.pow(0.0016, dt);
      let dTheta = cameraRig.targetTheta - cameraRig.theta;
      dTheta = Math.atan2(Math.sin(dTheta), Math.cos(dTheta));
      cameraRig.theta += dTheta * smooth;
      cameraRig.phi = lerp(cameraRig.phi, cameraRig.targetPhi, smooth);
      cameraRig.radius = lerp(cameraRig.radius, cameraRig.targetRadius, smooth);
      cameraRig.center.lerp(cameraRig.targetCenter, smooth);
    }

    const horizontal = cameraRig.radius * Math.cos(cameraRig.phi);
    camera.position.set(
      cameraRig.center.x + horizontal * Math.sin(cameraRig.theta),
      cameraRig.center.y + cameraRig.radius * Math.sin(cameraRig.phi),
      cameraRig.center.z + horizontal * Math.cos(cameraRig.theta)
    );
    camera.lookAt(cameraRig.center);

    const compassNeedle = $('compassNeedle');
    if (compassNeedle) {
      const deg = (cameraRig.theta * 180) / Math.PI;
      compassNeedle.style.transform = `rotate(${deg}deg)`;
    }

    // 标注按镜头远近渐隐，形成两层地理信息
    if (labelGroup && appState.labelsVisible) {
      const radius = cameraRig.radius;
      labelSprites.forEach((sprite) => {
        const base = sprite.userData.baseOpacity;
        const type = sprite.userData.type;
        const fade = type === 'province'
          ? 1 - smoothstep(112, 188, radius) * 0.86
          : 1 - smoothstep(76, 145, radius) * 0.28;
        sprite.material.opacity = base * fade;
      });
    }
  }

  function smoothstep(a, b, x) {
    const t = clamp((x - a) / (b - a), 0, 1);
    return t * t * (3 - 2 * t);
  }

  function resetView(instant) {
    cameraRig.targetTheta = -0.13;
    cameraRig.targetPhi = 0.72;
    cameraRig.targetRadius = defaultOverviewRadius();
    cameraRig.targetCenter.set(-2.4, 2.2, 0);
    appState.lastInteraction = performance.now();
    if (instant) updateCamera(0, true);
  }

  function flyToSpot(index) {
    const p = markerData[index];
    if (!p) return;
    cameraRig.targetCenter.set(p.x, p.y + 0.75, p.z);
    cameraRig.targetRadius = 77;
    cameraRig.targetPhi = 0.94;
    // 从南偏东的方向俯瞰，山脉层次更清晰
    const base = cameraRig.theta;
    const desired = 0.02;
    let diff = desired - base;
    diff = Math.atan2(Math.sin(diff), Math.cos(diff));
    cameraRig.targetTheta = base + diff;
    appState.lastInteraction = performance.now();
  }

  function onResize() {
    if (!renderer || !camera) return;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    if (haloPoints) haloPoints.material.uniforms.uPixelRatio.value = renderer.getPixelRatio();
    if (starField) starField.material.uniforms.uPixelRatio.value = renderer.getPixelRatio();
  }

  function currentPointerMarker(mx, my, threshold) {
    if (!camera || !markerData.length) return { index: -1, x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const nx = ((mx - rect.left) / rect.width) * 2 - 1;
    const ny = -((my - rect.top) / rect.height) * 2 + 1;
    let best = -1;
    let bestDist = (threshold || 15) * (threshold || 15);
    let bestX = 0, bestY = 0;
    for (let i = 0; i < markerData.length; i++) {
      const p = markerData[i];
      projected.set(p.x, p.markerY, p.z);
      // 地图未完成隆起时不做命中
      if (!appState.introDone) break;
      projected.project(camera);
      if (projected.z > 1 || projected.z < -1) continue;
      const sx = (projected.x * 0.5 + 0.5) * rect.width + rect.left;
      const sy = (-projected.y * 0.5 + 0.5) * rect.height + rect.top;
      const d = (sx - mx) * (sx - mx) + (sy - my) * (sy - my);
      if (d < bestDist) {
        bestDist = d;
        best = i;
        bestX = sx;
        bestY = sy;
      }
    }
    return { index: best, x: bestX, y: bestY };
  }

  function updateHover(force) {
    if (!appState.ready || !appState.introDone || appState.spotOpen || appState.infoOpen || appState.dragging || !appState.pointerInside) {
      if (appState.hovered !== -1) setHovered(-1);
      return;
    }
    const now = performance.now();
    if (!force && now - appState.lastHoverCheck < 40) return;
    appState.lastHoverCheck = now;
    const hit = currentPointerMarker(appState.pointerX, appState.pointerY, 16);
    setHovered(hit.index, hit.x, hit.y);
  }

  function setHovered(index, sx, sy) {
    if (index === appState.hovered && !(index >= 0)) return;
    const previous = appState.hovered;
    appState.hovered = index;
    if (previous !== index) {
      if (previous >= 0) updateMarkerAppearance(previous);
      if (index >= 0) updateMarkerAppearance(index);
    }
    canvas.classList.toggle('is-hover', index >= 0);
    if (index >= 0) {
      const spot = SPOTS[index];
      const p = markerData[index];
      const elevation = Math.round(sampleElevation(p.x, p.z));
      tipName.textContent = spot.shortName || spot.name;
      tipMeta.textContent = `${spot.province} · ${formatNumber(elevation)} m · 5A`;
      markerTip.classList.add('is-visible');
      positionTip(sx, sy);
    } else {
      markerTip.classList.remove('is-visible');
    }
  }

  function positionTip(sx, sy) {
    if (!Number.isFinite(sx) || !Number.isFinite(sy)) return;
    const width = markerTip.offsetWidth || 190;
    const height = markerTip.offsetHeight || 48;
    let x = sx + 20;
    let y = sy + 16;
    if (x + width > innerWidth - 16) x = sx - width - 20;
    if (y + height > innerHeight - 16) y = sy - height - 15;
    markerTip.style.left = `${Math.max(10, x)}px`;
    markerTip.style.top = `${Math.max(10, y)}px`;
  }

  function bindMapControls() {
    canvas.style.touchAction = 'none';

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    canvas.addEventListener('pointerdown', (e) => {
      if (!appState.ready || appState.spotOpen || appState.infoOpen) return;
      if (e.button !== 0 && e.button !== 2) return;
      appState.dragging = true;
      appState.dragButton = e.button;
      appState.dragStartX = appState.dragLastX = e.clientX;
      appState.dragStartY = appState.dragLastY = e.clientY;
      appState.dragDistance = 0;
      appState.pointerInside = true;
      canvas.classList.add('is-dragging');
      canvas.setPointerCapture?.(e.pointerId);
      appState.lastInteraction = performance.now();
      markerTip.classList.remove('is-visible');
      document.body.style.userSelect = 'none';
    });

    canvas.addEventListener('pointermove', (e) => {
      appState.pointerX = e.clientX;
      appState.pointerY = e.clientY;
      appState.pointerInside = true;
      if (!appState.dragging) {
        updateHover();
        return;
      }
      const dx = e.clientX - appState.dragLastX;
      const dy = e.clientY - appState.dragLastY;
      appState.dragLastX = e.clientX;
      appState.dragLastY = e.clientY;
      appState.dragDistance += Math.abs(dx) + Math.abs(dy);
      appState.lastInteraction = performance.now();
      if (appState.dragButton === 2) {
        // 平移：沿相机右方向与屏幕前向移动中心点
        const theta = cameraRig.theta;
        const rightX = Math.cos(theta);
        const rightZ = -Math.sin(theta);
        const forwardX = -Math.sin(theta);
        const forwardZ = -Math.cos(theta);
        const speed = cameraRig.radius * 0.00125;
        cameraRig.targetCenter.x += (-dx * rightX + dy * forwardX) * speed;
        cameraRig.targetCenter.z += (-dx * rightZ + dy * forwardZ) * speed;
        cameraRig.targetCenter.x = clamp(cameraRig.targetCenter.x, -64, 64);
        cameraRig.targetCenter.z = clamp(cameraRig.targetCenter.z, -48, 48);
      } else {
        cameraRig.targetTheta -= dx * 0.0043;
        cameraRig.targetPhi = clamp(cameraRig.targetPhi + dy * 0.0032, cameraRig.minPhi, cameraRig.maxPhi);
      }
    });

    const endDrag = (e) => {
      if (!appState.dragging) return;
      const wasClick = appState.dragButton === 0 && appState.dragDistance < 6;
      appState.dragging = false;
      appState.dragButton = -1;
      canvas.classList.remove('is-dragging');
      document.body.style.userSelect = '';
      appState.lastInteraction = performance.now();
      try { canvas.releasePointerCapture?.(e.pointerId); } catch (_) {}
      if (wasClick) handleCanvasClick(e.clientX, e.clientY);
      else updateHover(true);
    };
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', (e) => {
      if (!appState.dragging) return;
      appState.dragging = false;
      appState.dragButton = -1;
      canvas.classList.remove('is-dragging');
      document.body.style.userSelect = '';
      try { canvas.releasePointerCapture?.(e.pointerId); } catch (_) {}
    });

    canvas.addEventListener('pointerleave', () => {
      appState.pointerInside = false;
      if (!appState.dragging) setHovered(-1);
    });
    canvas.addEventListener('pointerenter', () => { appState.pointerInside = true; });

    window.addEventListener('wheel', (e) => {
      if (appState.spotOpen || appState.infoOpen) return;
      if (e.target.closest && e.target.closest('.search, .spot-panel, .info-panel, .icon-btn, .btn')) return;
      e.preventDefault();
      cameraRig.targetRadius = clamp(cameraRig.targetRadius * Math.exp(e.deltaY * 0.00125), cameraRig.minRadius, cameraRig.maxRadius);
      appState.lastInteraction = performance.now();
      updateHover(true);
    }, { passive: false });

    window.addEventListener('keydown', (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      const isTyping = tag === 'input' || tag === 'textarea' || e.target.isContentEditable;
      if (e.key === 'Escape') {
        if (isSearchOpen()) { hideSearch(); $('searchInput').blur(); return; }
        if (appState.infoOpen) { closeInfo(); return; }
        if (appState.spotOpen) { closeSpot(); return; }
      }
      if (!isTyping && e.key === '/') {
        e.preventDefault();
        $('searchInput').focus();
        return;
      }
      if (appState.spotOpen) {
        if (e.key === 'ArrowLeft') { e.preventDefault(); moveGallery(-1); }
        if (e.key === 'ArrowRight') { e.preventDefault(); moveGallery(1); }
      }
    });
  }

  function handleCanvasClick(mx, my) {
    const hit = currentPointerMarker(mx, my, 18);
    if (hit.index >= 0) {
      flyToSpot(hit.index);
      openSpot(hit.index);
    }
  }

  /* =========================================================
     6. UI 交互
     ========================================================= */
  function bindUI() {
    // 自动旋转
    const autoBtn = $('autoBtn');
    autoBtn.classList.toggle('is-on', appState.autoRotate);
    autoBtn.setAttribute('aria-pressed', String(appState.autoRotate));
    autoBtn.dataset.tip = appState.autoRotate ? '暂停自动旋转' : '开启自动旋转';
    autoBtn.addEventListener('click', () => {
      appState.autoRotate = !appState.autoRotate;
      autoBtn.classList.toggle('is-on', appState.autoRotate);
      autoBtn.setAttribute('aria-pressed', String(appState.autoRotate));
      autoBtn.dataset.tip = appState.autoRotate ? '暂停自动旋转' : '开启自动旋转';
      appState.lastInteraction = performance.now();
    });

    // 地理标注
    const labelBtn = $('labelBtn');
    labelBtn.classList.toggle('is-on', appState.labelsVisible);
    labelBtn.setAttribute('aria-pressed', String(appState.labelsVisible));
    labelBtn.addEventListener('click', () => {
      appState.labelsVisible = !appState.labelsVisible;
      labelGroup.visible = appState.labelsVisible;
      labelBtn.classList.toggle('is-on', appState.labelsVisible);
      labelBtn.setAttribute('aria-pressed', String(appState.labelsVisible));
      labelBtn.dataset.tip = appState.labelsVisible ? '隐藏地理标注' : '显示地理标注';
    });

    $('resetBtn').addEventListener('click', () => {
      closeSpot(true);
      closeInfo();
      resetView(false);
    });

    $('brandHome').addEventListener('click', (e) => {
      e.preventDefault();
      closeSpot(true);
      closeInfo();
      resetView(false);
    });

    // 全屏
    const fsBtn = $('fsBtn');
    fsBtn.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } else {
        document.exitFullscreen?.().catch(() => {});
      }
    });
    document.addEventListener('fullscreenchange', () => {
      fsBtn.dataset.tip = document.fullscreenElement ? '退出全屏' : '全屏体验';
      onResize();
    });

    // 关于
    $('infoBtn').addEventListener('click', openInfo);
    $('guideBtn').addEventListener('click', openInfo);
    $('infoClose').addEventListener('click', closeInfo);
    const infoModal = $('infoModal');
    infoModal.addEventListener('click', (e) => {
      if (e.target === infoModal || e.target.closest('[data-close-info]')) closeInfo();
    });

    // 缩放
    $('zoomIn').addEventListener('click', () => {
      cameraRig.targetRadius = clamp(cameraRig.targetRadius * 0.78, cameraRig.minRadius, cameraRig.maxRadius);
      appState.lastInteraction = performance.now();
    });
    $('zoomOut').addEventListener('click', () => {
      cameraRig.targetRadius = clamp(cameraRig.targetRadius * 1.28, cameraRig.minRadius, cameraRig.maxRadius);
      appState.lastInteraction = performance.now();
    });

    // 随机抵达
    $('surpriseBtn').addEventListener('click', () => {
      if (!SPOTS.length) return;
      const featured = SPOTS.filter((s) => s.featured);
      const pool = Math.random() < 0.58 && featured.length ? featured : SPOTS;
      const pick = pool[Math.floor(Math.random() * pool.length)];
      const index = SPOTS.indexOf(pick);
      flyToSpot(index);
      openSpot(index, { skipFly: true });
    });

    // 景区详情关闭 / 背景关闭
    $('spotClose').addEventListener('click', () => closeSpot());
    const spotModal = $('spotModal');
    spotModal.addEventListener('click', (e) => {
      if (e.target === spotModal || e.target.closest('[data-close-modal]')) closeSpot();
    });
    $('locateBtn').addEventListener('click', () => {
      const i = appState.activeSpot;
      if (i >= 0) flyToSpot(i);
      closeSpot();
    });

    // 图集
    $('galleryPrev').addEventListener('click', () => moveGallery(-1));
    $('galleryNext').addEventListener('click', () => moveGallery(1));
    $('galleryThumbs').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-slide]');
      if (!btn) return;
      showSlide(Number(btn.dataset.slide));
    });

    // 景区切换
    $('spotPrev').addEventListener('click', () => {
      if (!SPOTS.length) return;
      const next = (appState.activeSpot - 1 + SPOTS.length) % SPOTS.length;
      flyToSpot(next);
      openSpot(next, { skipFly: true, keepOpen: true });
    });
    $('spotNext').addEventListener('click', () => {
      if (!SPOTS.length) return;
      const next = (appState.activeSpot + 1) % SPOTS.length;
      flyToSpot(next);
      openSpot(next, { skipFly: true, keepOpen: true });
    });

    bindVideoControls();
    bindSearch();
    updateSpotCount();
  }

  function updateSpotCount() {
    if ($('statSpots')) $('statSpots').textContent = SPOTS.length || '358';
  }

  function openInfo() {
    if (appState.spotOpen) closeSpot(true);
    appState.infoOpen = true;
    appState.lastInteraction = performance.now();
    const modal = $('infoModal');
    appState.lastFocus = document.activeElement;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    $('infoClose').focus({ preventScroll: true });
  }

  function closeInfo() {
    if (!appState.infoOpen) return;
    appState.infoOpen = false;
    const modal = $('infoModal');
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    if (!appState.spotOpen) document.body.classList.remove('modal-open');
    if (appState.lastFocus && document.contains(appState.lastFocus)) {
      appState.lastFocus.focus({ preventScroll: true });
    }
  }

  /* =========================================================
     搜索
     ========================================================= */
  function isSearchOpen() {
    return !$('searchPanel').hidden;
  }

  function showSearch() {
    const panel = $('searchPanel');
    panel.hidden = false;
    const q = $('searchInput').value.trim();
    renderSearch(q);
  }

  function hideSearch() {
    $('searchPanel').hidden = true;
    appState.searchActive = -1;
  }

  function bindSearch() {
    const input = $('searchInput');
    input.addEventListener('focus', showSearch);
    input.addEventListener('input', () => {
      $('searchClear').hidden = !input.value.length;
      renderSearch(input.value.trim());
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (!isSearchOpen()) showSearch();
        if (!appState.searchResults.length) return;
        const dir = e.key === 'ArrowDown' ? 1 : -1;
        appState.searchActive = (appState.searchActive + dir + appState.searchResults.length) % appState.searchResults.length;
        updateSearchActive();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const pick = appState.searchResults[appState.searchActive] || appState.searchResults[0];
        if (pick) chooseSearchResult(pick.__index);
      } else if (e.key === 'Escape') {
        hideSearch();
        input.blur();
      }
    });

    $('searchClear').addEventListener('click', () => {
      input.value = '';
      $('searchClear').hidden = true;
      input.focus();
      renderSearch('');
    });

    $('searchResults').addEventListener('click', (e) => {
      const item = e.target.closest('[data-result-index]');
      if (!item) return;
      chooseSearchResult(Number(item.dataset.resultIndex));
    });

    $('searchResults').addEventListener('mousemove', (e) => {
      const item = e.target.closest('[data-result-index]');
      if (!item) return;
      const idx = appState.searchResults.findIndex((s) => s.__index === Number(item.dataset.resultIndex));
      if (idx >= 0 && idx !== appState.searchActive) {
        appState.searchActive = idx;
        updateSearchActive();
      }
    });

    document.addEventListener('pointerdown', (e) => {
      if (!e.target.closest('#search')) hideSearch();
    });
  }

  function renderSearch(query) {
    const panel = $('searchPanel');
    if (!panel || panel.hidden) return;
    const q = (query || '').toLowerCase();
    let results;
    if (!q) {
      results = SPOTS.filter((s) => s.featured).slice(0, 8);
      if (results.length < 6) results = results.concat(SPOTS.filter((s) => !s.featured).slice(0, 8 - results.length));
    } else {
      results = SPOTS.filter((s) => {
        const hay = `${s.name} ${s.shortName || ''} ${s.province} ${s.city || ''} ${(s.tags || []).join('')} ${s.name_en || ''}`.toLowerCase();
        return hay.includes(q);
      });
      // 名称命中的优先
      results.sort((a, b) => {
        const ai = (a.shortName || a.name).toLowerCase().indexOf(q);
        const bi = (b.shortName || b.name).toLowerCase().indexOf(q);
        if (ai === 0 && bi !== 0) return -1;
        if (bi === 0 && ai !== 0) return 1;
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
      results = results.slice(0, 14);
    }
    appState.searchResults = results;
    appState.searchActive = results.length ? 0 : -1;
    $('searchPanelLabel').textContent = q ? `找到 ${results.length} 处山河` : '热门目的地';
    $('searchEmpty').hidden = results.length > 0;

    $('searchResults').innerHTML = results.map((s, i) => {
      const tags = (s.tags || []).slice(0, 2).join(' · ');
      return `<button class="search-result${i === 0 ? ' is-active' : ''}" data-result-index="${s.__index}" role="option" aria-selected="${i === 0}">
        <span class="search-result__badge">5A</span>
        <span class="search-result__body"><strong>${escapeHTML(s.shortName || s.name)}</strong><span>${escapeHTML(s.province)} · ${escapeHTML(tags)}</span></span>
        <span class="search-result__go">↗</span>
      </button>`;
    }).join('');
    if (!results.length) $('searchResults').innerHTML = '';
  }

  function updateSearchActive() {
    const nodes = [...$('searchResults').querySelectorAll('.search-result')];
    nodes.forEach((node, i) => {
      const active = i === appState.searchActive;
      node.classList.toggle('is-active', active);
      node.setAttribute('aria-selected', String(active));
      if (active) node.scrollIntoView({ block: 'nearest' });
    });
  }

  function chooseSearchResult(index) {
    const spot = SPOTS[index];
    if (!spot) return;
    hideSearch();
    $('searchInput').blur();
    flyToSpot(index);
    openSpot(index, { skipFly: true });
  }

  /* =========================================================
     景区详情弹窗
     ========================================================= */
  function openSpot(index, opts) {
    const spot = SPOTS[index];
    if (!spot) return;
    const firstOpen = !appState.spotOpen;
    if (appState.infoOpen) closeInfo();
    if (!opts || !opts.skipFly) flyToSpot(index);
    appState.spotOpen = true;
    appState.activeSpot = index;
    appState.selected = index;
    appState.lastInteraction = performance.now();
    appState.lastHoverCheck = 0;
    setHovered(-1);
    setSelectedFx(index, true);
    updateMarkerAppearance(index);

    if (firstOpen) appState.lastFocus = document.activeElement;

    fillSpot(spot, index);

    const modal = $('spotModal');
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    if (firstOpen) {
      $('spotClose').focus({ preventScroll: true });
      // 首次打开时重新冲入过渡（内容切换时不播放整块弹窗动画）
      const panel = modal.querySelector('.spot-panel');
      if (panel) { panel.style.transition = 'none'; requestAnimationFrame(() => { panel.style.transition = ''; }); }
    }
  }

  function closeSpot(immediate) {
    if (!appState.spotOpen) return;
    appState.spotOpen = false;
    appState.selected = -1;
    setSelectedFx(-1, false);
    updateMarkerAppearance(appState.activeSpot);
    appState.activeSpot = -1;
    pauseVideo();
    const modal = $('spotModal');
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    if (!appState.infoOpen) document.body.classList.remove('modal-open');
    appState.lastInteraction = performance.now();
    markerTip.classList.remove('is-visible');
    if (!immediate && appState.lastFocus && document.contains(appState.lastFocus)) {
      appState.lastFocus.focus({ preventScroll: true });
    }
  }

  function fillSpot(spot, index) {
    const elevation = Math.round(sampleElevation(markerData[index].x, markerData[index].z));
    $('spotRegion').textContent = `中国 · ${spot.province}`;
    $('spotCoord').textContent = `N ${spot.lat.toFixed(2)}° · E ${spot.lon.toFixed(2)}°`;
    $('spotTitle').textContent = spot.shortName || spot.name;
    $('spotSubtitle').textContent = spot.subtitle || '一处被山河珍藏的中国风景';
    $('spotTags').innerHTML = (spot.tags || []).slice(0, 4).map((t) => `<span>${escapeHTML(t)}</span>`).join('');

    const facts = [
      ['地理位置', spot.province, spot.city ? ` · ${spot.city}` : ''],
      ['点位海拔', formatNumber(elevation), ' m'],
      ['推荐时节', spot.bestSeason || '四季皆宜', ''],
      ['建议停留', spot.durationCn || '半日', ''],
    ];
    $('spotFacts').innerHTML = facts.map(([k, v, extra]) => `<div><dt>${escapeHTML(k)}</dt><dd>${escapeHTML(v)}${extra ? escapeHTML(extra) : ''}</dd></div>`).join('');

    const intro = Array.isArray(spot.intro) && spot.intro.length ? spot.intro : [spot.description || '这处5A级旅游景区位于中国大地之上，等待你亲自抵达。'];
    $('spotIntro').innerHTML = intro.map((p) => `<p>${escapeHTML(p)}</p>`).join('');

    const highlights = Array.isArray(spot.highlights) && spot.highlights.length
      ? spot.highlights
      : (spot.tags || []).map((t) => `${t}，是这里最值得停步的风景。`);
    $('spotHighlights').innerHTML = highlights.map((h) => {
      const text = escapeHTML(h);
      return `<li>${text}</li>`;
    }).join('');

    $('spotQuote').querySelector('p').textContent = spot.quote || '山川不语，却把时间写进了每一道褶皱。';
    const sourceLink = $('spotSourceLink');
    sourceLink.href = spot.pageUrl || '#';
    sourceLink.style.display = spot.pageUrl ? '' : 'none';

    setupGallery(spot);
    setupVideo(spot);
    $('spotScroll').scrollTop = 0;
  }

  function placeholderImage(spot) {
    return makePlaceholder(spot.shortName || spot.name);
  }

  function setupGallery(spot) {
    const images = (spot.images && spot.images.length ? spot.images : [{ url: '' }]).slice(0, 4);
    // 保证至少有 3 张可翻看的画面
    while (images.length < 3) images.push(images[images.length - 1]);
    appState.galleryImages = images;
    appState.galleryIndex = 0;
    $('galleryTotal').textContent = String(images.length).padStart(2, '0');
    const localPlaceholder = placeholderImage(spot);
    $('galleryThumbs').innerHTML = images.map((img, i) => {
      const thumbSrc = img.url || img.fallbackUrl || img.fallbackLocal || localPlaceholder;
      return `
      <button class="gallery-thumb${i === 0 ? ' is-active' : ''}" data-slide="${i}" aria-label="查看第${i + 1}张图片">
        <img src="${escapeHTML(thumbSrc)}" alt="" loading="eager" referrerpolicy="no-referrer">
        <span class="gallery-thumb__num">0${i + 1}</span>
      </button>`;
    }).join('');
    $('galleryThumbs').querySelectorAll('img').forEach((thumb, i) => {
      thumb.addEventListener('error', () => {
        const img = images[i] || {};
        const fallback = img.fallbackLocal || localPlaceholder;
        if (thumb.src !== fallback) thumb.src = fallback;
      });
    });
    showSlide(0);
  }

  function showSlide(index) {
    if (!appState.galleryImages.length) return;
    const total = appState.galleryImages.length;
    const i = ((index % total) + total) % total;
    appState.galleryIndex = i;
    const img = appState.galleryImages[i];
    const main = $('galleryMain');
    const stage = $('galleryStage');
    const token = ++appState.galleryToken;
    const spotName = appState.activeSpot >= 0 ? (SPOTS[appState.activeSpot].shortName || SPOTS[appState.activeSpot].name) : '';
    $('galleryIndex').textContent = String(i + 1).padStart(2, '0');
    $('galleryCaption').textContent = `${spotName} · ${img.caption || '实景影像'}`;
    stage.classList.remove('is-ready');
    main.classList.remove('is-loaded');
    main.alt = `${$('spotTitle').textContent} 实景影像 ${i + 1}`;
    main.referrerPolicy = 'no-referrer';

    // 依次尝试：原图 → Bing 缩略图 → 本地区域风光 → 绘制占位图
    const placeholder = placeholderImage({ shortName: $('spotTitle').textContent });
    const candidates = [img.url, img.fallbackUrl, img.fallbackLocal, placeholder].filter(Boolean);
    const localIndex = img.fallbackLocal ? candidates.indexOf(img.fallbackLocal) : -1;
    let cursor = 0;
    let retryTimer = null;
    const setCaption = (sourceIndex) => {
      let caption = img.caption || '实景影像';
      if (sourceIndex === candidates.length - 1) caption = '影像整理中';
      else if (localIndex >= 0 && sourceIndex >= localIndex) caption = '区域风光';
      $('galleryCaption').textContent = `${spotName} · ${caption}`;
    };
    const attempt = () => {
      if (token !== appState.galleryToken) return;
      clearTimeout(retryTimer);
      if (cursor >= candidates.length) {
        main.src = placeholder;
        setCaption(candidates.length - 1);
        main.classList.add('is-loaded');
        stage.classList.add('is-ready');
        return;
      }
      const current = cursor++;
      main.classList.remove('is-loaded');
      stage.classList.remove('is-ready');
      main.src = candidates[current];
      setCaption(current);
      // 网络图片不可达时，不让用户一直等待
      retryTimer = setTimeout(() => {
        if (token === appState.galleryToken && !main.complete) attempt();
      }, 4000);
    };
    main.onload = () => {
      if (token !== appState.galleryToken) return;
      clearTimeout(retryTimer);
      main.classList.add('is-loaded');
      stage.classList.add('is-ready');
    };
    main.onerror = () => {
      if (token !== appState.galleryToken) return;
      clearTimeout(retryTimer);
      main.classList.remove('is-loaded');
      stage.classList.remove('is-ready');
      attempt();
    };
    attempt();
    if (main.complete && main.naturalWidth > 0) {
      main.classList.add('is-loaded');
      stage.classList.add('is-ready');
    }
    $('galleryThumbs').querySelectorAll('.gallery-thumb').forEach((thumb, idx) => thumb.classList.toggle('is-active', idx === i));
  }

  function moveGallery(dir) {
    if (!appState.galleryImages || !appState.galleryImages.length) return;
    showSlide(appState.galleryIndex + dir);
  }

  /* =========================================================
     视频模块
     ========================================================= */
  const VIDEO_THEME_LABELS = {
    mountain: '群山回响 · MOUNTAIN STUDY',
    snow: '雪线之上 · SNOW STUDY',
    forest: '林海呼吸 · FOREST STUDY',
    waterfall: '飞瀑流泉 · WATERFALL STUDY',
    desert: '大漠长风 · DESERT STUDY',
    lake: '湖畔光阴 · LAKE STUDY',
    river: '长河奔流 · RIVER STUDY',
    sea: '向海而生 · OCEAN STUDY',
    heritage: '古建晨昏 · HERITAGE STUDY',
    city: '城事流光 · CITY STUDY',
    grassland: '草野无垠 · GRASSLAND STUDY',
  };

  function setupVideo(spot) {
    const video = $('spotVideo');
    const frame = $('videoFrame');
    const poster = $('videoPoster');
    video.pause();
    video.removeAttribute('src');
    frame.classList.remove('is-playing', 'has-started');
    $('videoError').classList.remove('is-on');
    $('videoLoader').classList.remove('is-on');
    video.muted = true;
    $('videoMute').classList.remove('is-unmuted');
    $('videoTime').textContent = '00:00 / 00:00';
    $('videoFill').style.width = '0%';
    $('videoProgressBuffer').style.width = '0%';
    $('videoProgress').setAttribute('aria-valuenow', '0');
    const firstImage = spot.images && spot.images[0] ? spot.images[0] : {};
    const posterUrl = firstImage.url || firstImage.fallbackUrl || firstImage.fallbackLocal || placeholderImage(spot);
    poster.style.backgroundImage = `url("${String(posterUrl).replace(/"/g, '\\"')}")`;
    $('videoTheme').textContent = VIDEO_THEME_LABELS[spot.videoTheme] || '主题影像 · MOTION STUDY';
    const caption = frame.querySelector('.video-overlay__caption strong');
    if (caption) caption.textContent = spot.videoCaption || '在流动的风景里，看见山河';
    const src = spot.video || 'videos/mountain.mp4';
    video.setAttribute('preload', 'metadata');
    video.src = src;
    video.load();
    frame.dataset.hasVideo = 'true';
  }

  function bindVideoControls() {
    const video = $('spotVideo');
    const frame = $('videoFrame');
    const overlay = $('videoOverlay');
    const fill = $('videoFill');
    const knob = $('videoKnob');
    const progress = $('videoProgress');
    const timeLabel = $('videoTime');
    const toggle = $('videoToggle');
    const bigPlay = $('videoBigPlay');
    const loaderEl = $('videoLoader');
    const errorEl = $('videoError');

    const formatTime = (sec) => {
      if (!Number.isFinite(sec) || sec < 0) return '00:00';
      const m = Math.floor(sec / 60);
      const s = Math.floor(sec % 60);
      return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    };

    const updateTime = () => {
      const duration = video.duration;
      const current = video.currentTime || 0;
      timeLabel.textContent = `${formatTime(current)} / ${formatTime(duration)}`;
      const pct = duration > 0 ? clamp((current / duration) * 100, 0, 100) : 0;
      fill.style.width = pct + '%';
      knob.style.left = pct + '%';
      progress.setAttribute('aria-valuenow', String(Math.round(pct)));
    };

    const play = () => {
      errorEl.classList.remove('is-on');
      if (!video.src) return;
      loaderEl.classList.add('is-on');
      const promise = video.play();
      if (promise && promise.catch) promise.catch(() => {
        loaderEl.classList.remove('is-on');
        // 有些浏览器在无用户授权时拒绝带声音的播放，这里静音重试
        if (!video.muted) {
          video.muted = true;
          $('videoMute').classList.remove('is-unmuted');
          video.play().catch(() => {});
        }
      });
    };

    const togglePlay = () => {
      if (video.paused) play(); else video.pause();
    };

    toggle.addEventListener('click', (e) => { e.stopPropagation(); togglePlay(); });
    bigPlay.addEventListener('click', (e) => { e.stopPropagation(); play(); });
    frame.addEventListener('click', (e) => {
      if (e.target.closest('.video-controls') || e.target.closest('#videoBigPlay')) return;
      togglePlay();
    });

    video.addEventListener('loadedmetadata', updateTime);
    video.addEventListener('timeupdate', updateTime);
    video.addEventListener('progress', () => {
      if (video.buffered.length && video.duration) {
        const end = video.buffered.end(video.buffered.length - 1);
        $('videoProgressBuffer').style.width = (end / video.duration * 100) + '%';
      }
    });
    video.addEventListener('play', () => {
      frame.classList.add('is-playing', 'has-started');
      $('videoToggle').setAttribute('aria-label', '暂停');
      $('videoBigPlay').setAttribute('aria-label', '暂停短片');
    });
    video.addEventListener('pause', () => {
      frame.classList.remove('is-playing');
      $('videoToggle').setAttribute('aria-label', '播放');
      $('videoBigPlay').setAttribute('aria-label', '播放短片');
      loaderEl.classList.remove('is-on');
    });
    video.addEventListener('playing', () => {
      loaderEl.classList.remove('is-on');
      errorEl.classList.remove('is-on');
    });
    video.addEventListener('canplay', () => loaderEl.classList.remove('is-on'));
    video.addEventListener('waiting', () => { if (!video.paused) loaderEl.classList.add('is-on'); });
    video.addEventListener('ended', () => {
      frame.classList.remove('is-playing');
      updateTime();
    });
    video.addEventListener('error', () => {
      loaderEl.classList.remove('is-on');
      errorEl.classList.add('is-on');
      frame.classList.remove('is-playing');
    });

    const seek = (clientX) => {
      const rect = progress.getBoundingClientRect();
      const ratio = clamp((clientX - rect.left) / rect.width, 0, 1);
      if (Number.isFinite(video.duration) && video.duration > 0) {
        video.currentTime = ratio * video.duration;
        updateTime();
      }
    };
    progress.addEventListener('click', (e) => seek(e.clientX));
    progress.addEventListener('pointerdown', (e) => {
      progress.setPointerCapture?.(e.pointerId);
      seek(e.clientX);
    });
    progress.addEventListener('pointermove', (e) => {
      if (e.buttons === 1) seek(e.clientX);
    });
    progress.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        e.preventDefault();
        video.currentTime = clamp(video.currentTime + (e.key === 'ArrowRight' ? 2 : -2), 0, video.duration || 0);
      }
    });
    $('videoMute').addEventListener('click', (e) => {
      e.stopPropagation();
      video.muted = !video.muted;
      $('videoMute').classList.toggle('is-unmuted', !video.muted);
      $('videoMute').setAttribute('aria-label', video.muted ? '开启声音' : '关闭声音');
    });
    $('videoFull').addEventListener('click', (e) => {
      e.stopPropagation();
      if (frame.requestFullscreen) frame.requestFullscreen().catch(() => {});
    });
  }

  function pauseVideo() {
    const video = $('spotVideo');
    if (video) video.pause();
  }

  /* =========================================================
     7. 启动 / 主循环
     ========================================================= */
  function animate() {
    requestAnimationFrame(animate);
    if (!renderer || !scene || !camera) return;
    const dt = Math.min(clock.getDelta(), 0.05);
    const now = performance.now();

    if (intro.running) {
      const t = clamp((now - intro.start) / intro.duration, 0, 1);
      const e = easeOutCubic(t);
      mapGroup.scale.y = 0.012 + 0.988 * e;
      if (t >= 1) {
        intro.running = false;
        intro.done = true;
        appState.introDone = true;
        mapGroup.scale.y = 1;
        // 地形静止后冻结阴影贴图，降低持续开销
        if (renderer.shadowMap) {
          renderer.shadowMap.needsUpdate = true;
          setTimeout(() => { if (renderer) renderer.shadowMap.autoUpdate = false; }, 60);
        }
        updateHover(true);
      }
    }

    updateCamera(dt, false);

    if (haloPoints) {
      haloPoints.material.uniforms.uTime.value = now * 0.001;
      haloPoints.material.uniforms.uHover.value = appState.hovered;
      haloPoints.material.uniforms.uSelected.value = appState.selected;
    }
    if (waterMesh) waterMesh.material.uniforms.uTime.value = now * 0.001;
    if (seaMesh) seaMesh.material.uniforms.uTime.value = now * 0.001;
    if (starField) starField.material.uniforms.uTime.value = now * 0.001;
    if (selectionRing && selectionRing.visible) {
      const pulse = 1 + Math.sin(now * 0.0024) * 0.09;
      selectionRing.scale.set(pulse, pulse, pulse);
      selectionRing.material.opacity = 0.55 + Math.sin(now * 0.0024) * 0.18;
    }
    if (selectionBeam && selectionBeam.visible) {
      selectionBeam.material.opacity = 0.66 + Math.sin(now * 0.0018) * 0.12;
    }

    if (appState.pointerInside && !appState.dragging && appState.ready && appState.introDone && !appState.spotOpen && !appState.infoOpen) {
      updateHover();
    }
    if (appState.hovered >= 0) {
      const hit = currentPointerMarker(appState.pointerX, appState.pointerY, 16);
      if (hit.index >= 0) positionTip(hit.x, hit.y);
    }

    renderer.render(scene, camera);
  }

  async function boot() {
    if (location.protocol === 'file:') {
      showFatal('请用本地静态服务器打开', '浏览器不允许 file:// 页面读取本地地形纹理。请在项目目录运行 start.bat，或执行 python -m http.server 8080 后访问 http://127.0.0.1:8080/。');
      return;
    }
    const bootStart = performance.now();
    loading.set(6, '解析真实高程栅格');
    initScene();
    bindUI();
    bindMapControls();
    updateCamera(0, true);
    mapGroup.scale.y = 0.012;

    loading.set(14, '铺展地表纹理');
    try {
      await loadTerrainAssets();
    } catch (err) {
      console.error(err);
      showFatal('地形纹理加载失败', '请通过本地静态服务器运行本页，例如在项目目录执行 python -m http.server 8080。');
      return;
    }

    loading.set(62, '雕刻山脉与高原');
    await new Promise((resolve) => requestAnimationFrame(resolve));
    buildTerrain();

    loading.set(76, '刻下海岸与国境');
    await new Promise((resolve) => requestAnimationFrame(resolve));
    buildMarkers();
    buildLabels();

    loading.set(92, '点亮 5A 山河坐标');
    await new Promise((resolve) => requestAnimationFrame(resolve));
    updateCamera(0, true);
    renderer.shadowMap.needsUpdate = true;
    renderer.render(scene, camera);

    // 预编译避免首帧卡顿
    loading.set(97, '校对光影');
    await wait(Math.max(320, 1500 - (performance.now() - bootStart)));

    loading.set(100, '山河已就位');
    await wait(320);
    loader.classList.add('is-done');
    document.body.classList.remove('is-loading');
    document.body.classList.add('is-ready');
    appState.ready = true;
    intro.start = performance.now();
    intro.running = true;
    appState.lastInteraction = performance.now() + 2200;
    // 从较远的视野缓缓推向中国；大屏自动贴近，让地形成为绝对主角
    const overviewRadius = defaultOverviewRadius();
    cameraRig.radius = overviewRadius + 44;
    cameraRig.targetRadius = overviewRadius;
    cameraRig.targetPhi = 0.72;
    cameraRig.phi = 0.76;
    animate();
  }

  window.addEventListener('DOMContentLoaded', boot);
})();
