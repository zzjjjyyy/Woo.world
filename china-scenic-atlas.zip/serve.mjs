// 零依赖静态服务器：node serve.mjs [port]
// 仅用于本地预览，不包含任何业务后端逻辑。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.argv[2] || 8080);
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.woff2': 'font/woff2',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

const server = http.createServer((req, res) => {
  try {
    const parsed = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    let relative = decodeURIComponent(parsed.pathname);
    if (relative === '/' || relative === '') relative = '/index.html';
    const full = path.normalize(path.join(root, relative));
    if (!full.startsWith(root + path.sep) && full !== root) {
      res.writeHead(403); res.end('Forbidden'); return;
    }
    const stat = fs.statSync(full);
    if (stat.isDirectory()) {
      res.writeHead(302, { Location: relative.replace(/\/?$/, '/') + 'index.html' }); res.end(); return;
    }
    res.writeHead(200, {
      'Content-Type': mime[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': 'no-cache',
    });
    fs.createReadStream(full).pipe(res);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404 · 未找到该文件');
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`山河志已启动：http://127.0.0.1:${port}/`);
  console.log('按 Ctrl+C 结束本地预览');
});
