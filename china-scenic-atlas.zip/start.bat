@echo off
setlocal
cd /d "%~dp0"
set PORT=8080

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  echo Starting China Scenic Atlas with Python...
  start "China Scenic Atlas Server" cmd /k "py -m http.server %PORT% --bind 127.0.0.1"
  timeout /t 1 /nobreak >nul
  start "" "http://127.0.0.1:%PORT%/"
  exit /b 0
)

where python >nul 2>nul
if %ERRORLEVEL%==0 (
  echo Starting China Scenic Atlas with Python...
  start "China Scenic Atlas Server" cmd /k "python -m http.server %PORT% --bind 127.0.0.1"
  timeout /t 1 /nobreak >nul
  start "" "http://127.0.0.1:%PORT%/"
  exit /b 0
)

where node >nul 2>nul
if %ERRORLEVEL%==0 (
  echo Starting China Scenic Atlas with Node.js...
  start "China Scenic Atlas Server" cmd /k "node serve.mjs %PORT%"
  timeout /t 1 /nobreak >nul
  start "" "http://127.0.0.1:%PORT%/"
  exit /b 0
)

echo.
echo  未找到 Python 或 Node.js。
echo  本页面需要本地静态服务器，不能直接双击 index.html。
echo  可安装 Python 3 / Node.js 后重新运行本脚本，
echo  或使用 VS Code 的 Live Server 打开此目录。
echo.
pause
